package expo.modules.noraview

import android.app.Activity
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.provider.MediaStore
import android.provider.DocumentsContract
import android.util.AttributeSet
import android.util.Log
import android.view.ContextMenu
import android.view.GestureDetector
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JsResult
import android.webkit.MimeTypeMap
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.ViewCompat
import androidx.webkit.ScriptHandler
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import expo.modules.kotlin.AppContext
import expo.modules.kotlin.viewevent.EventDispatcher
import expo.modules.kotlin.views.ExpoView
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.charset.Charset
import java.util.Base64
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.apache.tika.Tika

val VIEW_HOSTS = arrayOf(
  "bsky.app",
  "www.linkedin.com",
  "www.instagram.com",
  "chat.reddit.com",
  "old.reddit.com",
  "www.reddit.com",
  "www.threads.com",
  "www.tiktok.com",
  "www.tumblr.com",
  "id.vk.com",
  "login.vk.com",
  "login.vk.ru",
  "m.vk.com",
  "vk.com",
  "x.com"
)

// https://www.whatismybrowser.com/guides/the-latest-user-agent/chrome
val uaAndroid = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.7444.172 Mobile Safari/537.36"
val uaLinux = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"

class NouWebView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0) :
  WebView(context, attrs, defStyleAttr) {

  private var pageActive = true
  private var appForeground = false

  init {
    settings.run {
      javaScriptEnabled = true
      domStorageEnabled = true
      mediaPlaybackRequiresUserGesture = false
      builtInZoomControls = true
      displayZoomControls = false
      setSupportMultipleWindows(true)
    }
    CookieManager.getInstance().setAcceptCookie(true)
    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

    // Suppress X-Requested-With (otherwise WebView sends the package name, which Google
    // uses to block OAuth as `disallowed_useragent`).
    if (WebViewFeature.isFeatureSupported(WebViewFeature.REQUESTED_WITH_HEADER_ALLOW_LIST)) {
      WebSettingsCompat.setRequestedWithHeaderOriginAllowList(settings, emptySet())
    }

    // https://stackoverflow.com/a/64564676
    setFocusable(true)
    setFocusableInTouchMode(true)

    // setWebContentsDebuggingEnabled(true)
    NoraWebViewLifecycle.register(this)
  }

  // Preserve a tab's own paused state across a whole-app background/foreground cycle.
  override fun onPause() {
    pageActive = false
    applyLifecycle()
  }

  override fun onResume() {
    pageActive = true
    applyLifecycle()
  }

  internal fun setAppForeground(value: Boolean) {
    appForeground = value
    applyLifecycle()
  }

  private fun applyLifecycle() {
    if (pageActive && appForeground) super.onResume() else super.onPause()
  }

  override fun destroy() {
    NoraWebViewLifecycle.unregister(this)
    super.destroy()
  }

  suspend fun eval(script: String): String? = suspendCancellableCoroutine { cont ->
    evaluateJavascript(script) { result ->
      if (result == "null") {
        cont.resume(null, null)
      } else {
        cont.resume(result, null)
      }
    }
  }
}

fun redirectFacebookUrl(url: String): String? {
  val uri = Uri.parse(url)
  if (uri.scheme == "fb" && uri.host == "fullscreen_video") {
    val videoId = uri.lastPathSegment
    if (videoId != null) {
      return "https://m.facebook.com/reel/$videoId/"
    }
  }
  return null
}

private fun isFacebookPathUrl(url: String, prefix: String): Boolean {
  val uri = runCatching { java.net.URI(url) }.getOrNull() ?: return false
  val path = uri.path ?: return false
  return uri.scheme == "https" &&
    (uri.host == "www.facebook.com" || uri.host == "m.facebook.com") &&
    (path == prefix || path.startsWith("$prefix/"))
}

fun isMessengerUrl(url: String): Boolean = isFacebookPathUrl(url, "/messages")

fun isMarketplaceUrl(url: String): Boolean = isFacebookPathUrl(url, "/marketplace")

fun isDesktopFacebookUrl(url: String): Boolean = isMessengerUrl(url) || isMarketplaceUrl(url)

// Share links (vm.tiktok.com, vt.tiktok.com) redirect to www.tiktok.com keeping the agent they
// were loaded with, so they need the desktop one too.
fun isTikTokUrl(url: String): Boolean {
  val uri = Uri.parse(url)
  val host = uri.host ?: return false
  return uri.scheme == "https" && (host == "tiktok.com" || host.endsWith(".tiktok.com"))
}

fun desktopFacebookUrl(url: String): String {
  return url.replaceFirst("https://m.facebook.com", "https://www.facebook.com")
}

fun shouldRedirectFacebookToMobile(currentUrl: String, targetUrl: String, desktopMode: Boolean): Boolean {
  if (desktopMode) {
    return false
  }
  if (!targetUrl.startsWith("https://www.facebook.com/")) {
    return false
  }
  if (isDesktopFacebookUrl(targetUrl)) {
    return false
  }
  if (isMessengerUrl(currentUrl)) {
    return false
  }
  return true
}

val INTERNAL_SCHEMES = setOf("about", "blob", "data", "file", "http", "https", "javascript", "nora")

const val SAVED_FILE_CHANNEL_ID = "nora-saved-files"

// Sites serve real images under decoy extensions so browsers render them inline
// instead of downloading them: Discord's .pnj is a PNG, .gifv a GIF. Imgur's
// .gifv holds an MP4 though, so a detected MIME type outranks this table.
val FILE_EXTENSION_ALIASES = mapOf(
  "pnj" to "png",
  "gifv" to "gif",
  "jfif" to "jpg",
  "jpe" to "jpg",
)

// Extension/MIME lookups, behind a seam so `normalizeFileName` can be tested
// without the framework's MimeTypeMap.
interface MimeTypeLookup {
  fun mimeTypeFor(extension: String): String?

  fun extensionFor(mimeType: String): String?
}

val systemMimeTypes = object : MimeTypeLookup {
  override fun mimeTypeFor(extension: String) =
    MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)

  override fun extensionFor(mimeType: String) =
    MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
}

// Gives a saved file an extension the media scanner understands. `detected` marks
// a MIME type read off the bytes or the blob itself, which can overrule the name;
// a type merely guessed from context only fills in a name with nothing usable.
// An unrecognized extension is otherwise left alone, private formats included --
// renaming one can be what stops the user loading the file back where it came from.
fun normalizeFileName(
  name: String,
  mimeType: String?,
  detected: Boolean = false,
  mimeTypes: MimeTypeLookup = systemMimeTypes
): String {
  val ext = name.substringAfterLast('.', "").lowercase()
  val extMimeType = if (ext == "") null else mimeTypes.mimeTypeFor(ext)
  val fromMimeType = mimeType?.let(mimeTypes::extensionFor)
  val alias = FILE_EXTENSION_ALIASES[ext]
  // Only a disagreement about the kind of file counts: sniffing routinely reads a
  // .csv as text/plain, and that must not rename it.
  val contradicted = detected &&
    fromMimeType != null &&
    extMimeType?.substringBefore('/') != mimeType.orEmpty().substringBefore('/')

  val replacement = when {
    extMimeType != null -> if (contradicted) fromMimeType else return name
    alias != null -> if (detected) fromMimeType ?: alias else alias
    ext == "" -> fromMimeType
    else -> null
  } ?: return name

  return if (ext == "") "$name.$replacement" else name.dropLast(ext.length) + replacement
}

// Hosts where Google runs WebView-detection for OAuth.
val GOOGLE_AUTH_HOSTS = setOf("accounts.google.com", "accounts.youtube.com")
val GOOGLE_AUTH_ORIGIN_RULES = GOOGLE_AUTH_HOSTS.map { "https://$it" }.toSet()

fun isGoogleOAuthPopupUrl(url: String): Boolean {
  val uri = Uri.parse(url)
  val host = uri.host?.lowercase() ?: return false
  if (host == "accounts.google.com" || host.startsWith("accounts.google.") || host == "accounts.youtube.com" || host.startsWith("accounts.youtube.")) {
    return true
  }
  val path = uri.path?.lowercase().orEmpty()
  val query = uri.query?.lowercase().orEmpty()
  if (host.contains("linkedin.com") && (path.contains("connect/google") || path.contains("oauth") || query.contains("google"))) {
    return true
  }
  if ((host.contains("twitter.com") || host.contains("x.com")) && (path.contains("/i/flow") || path.contains("oauth") || query.contains("google"))) {
    return true
  }
  if (host == "appleid.apple.com") {
    return true
  }
  return false
}

// Masks WebView-only fingerprints that Google's sign-in checks.
val OAUTH_SHIM_SCRIPT = """
  (function() {
    try {
      Object.defineProperty(navigator, 'webdriver', { get: function() { return undefined; }, configurable: true });
    } catch (e) {}
    try {
      if (!window.chrome) { window.chrome = {}; }
      if (!window.chrome.runtime) { window.chrome.runtime = {}; }
      if (!window.chrome.app) { window.chrome.app = { isInstalled: false }; }
      if (!window.chrome.csi) { window.chrome.csi = function() { return {}; }; }
      if (!window.chrome.loadTimes) { window.chrome.loadTimes = function() { return {}; }; }
    } catch (e) {}
  })();
""".trimIndent()

fun installGoogleOAuthShim(webView: WebView) {
  if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
    WebViewCompat.addDocumentStartJavaScript(webView, OAUTH_SHIM_SCRIPT, GOOGLE_AUTH_ORIGIN_RULES)
  }
}

/**
 * @param openInApp when set, a link that asks for an app can be answered by loading its web page
 * here, in the tab; it is set only while the anonymous mode is on for the tab, see [inAppUrlFor].
 * @param followed whether the person followed the link, rather than the page going there on its own.
 */
fun shouldNoraOverrideUrlLoading(
  view: WebView,
  url: String,
  openInApp: ((String) -> Unit)? = null,
  followed: Boolean = true,
): Boolean {
  val uri = Uri.parse(url)
  if (uri.scheme?.lowercase() !in INTERNAL_SCHEMES) {
    return handleExternalAppUrl(view.context, url, openInApp, followed)
  }

  if (!shouldOpenInSystemBrowser(uri)) {
    return false
  }
  return openInSystemBrowser(view.context, uri)
}

/** A web link to a host Nora doesn't handle itself, while the setting to leave such links to the system browser is on. */
fun shouldOpenInSystemBrowser(uri: Uri): Boolean {
  if (!nouController.settings.openExternalLinkInSystemBrowser) return false
  if (uri.scheme?.lowercase() !in INTERNAL_SCHEMES) return false
  val host = uri.host
  val normalizedHost = host?.lowercase()
  val dynamicInternalHosts = nouController.settings.internalHosts.map { it.lowercase() }.toSet()
  val isFacebookHost = normalizedHost?.endsWith(".facebook.com") == true && normalizedHost != "l.facebook.com"
  return !(host in VIEW_HOSTS || (normalizedHost != null && normalizedHost in dynamicInternalHosts) || isFacebookHost)
}

fun openInSystemBrowser(context: Context, uri: Uri): Boolean {
  try {
    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
  } catch (e: ActivityNotFoundException) {
    e.printStackTrace()
  }
  return true
}

// `<input accept>` may carry extensions (`.jpg`), bare MIME types
// (`image/png`) or comma separated lists in a single entry. Turn all of them
// into a plain MIME list the document picker understands.
fun normalizeAcceptTypes(acceptTypes: Array<String>?): Array<String> {
  val mimeTypes = LinkedHashSet<String>()
  acceptTypes?.forEach { entry ->
    entry.split(",").forEach { raw ->
      val accept = raw.trim()
      when {
        accept.isEmpty() -> {}
        accept.startsWith(".") -> {
          val mimeType = MimeTypeMap.getSingleton()
            .getMimeTypeFromExtension(accept.substring(1).lowercase())
          if (mimeType != null) {
            mimeTypes.add(mimeType)
          }
        }
        accept.contains("/") -> mimeTypes.add(accept.lowercase())
        else -> {
          val mimeType = MimeTypeMap.getSingleton().getMimeTypeFromExtension(accept.lowercase())
          if (mimeType != null) {
            mimeTypes.add(mimeType)
          }
        }
      }
    }
  }
  return mimeTypes.toTypedArray()
}

/**
 * The address inside Nora that a web address stands for, or null when it is not a
 * page of a site Nora shows. Instagram's app links name `instagram.com` where Nora's
 * hosts are `www.instagram.com`, so the `www.` form counts as the same site.
 */
fun inAppUrlFor(url: String?, hosts: Collection<String>): String? {
  if (url.isNullOrEmpty()) {
    return null
  }
  val uri = try {
    java.net.URI(url)
  } catch (e: java.net.URISyntaxException) {
    return null
  }
  val scheme = uri.scheme?.lowercase()
  val host = uri.host?.lowercase()
  if ((scheme != "http" && scheme != "https") || host == null) {
    return null
  }
  // `applink.instagram.com` is how Instagram names its page when it asks for the app.
  val site = host.removePrefix("applink.")
  val target = listOf(host, "www.$host", site, "www.$site").firstOrNull { it in hosts } ?: return null
  // Always https: a page that was asked for here is not to get round the setting that blocks plain http.
  return buildString {
    append("https://").append(target)
    append(uri.rawPath ?: "")
    uri.rawQuery?.let { append("?").append(it) }
    uri.rawFragment?.let { append("#").append(it) }
  }
}

/** The sites Nora shows, which is what an app link is checked against. */
private fun inAppHosts() = VIEW_HOSTS.toList() + nouController.settings.internalHosts.map { it.lowercase() }

fun handleExternalAppUrl(context: Context, url: String, openInApp: ((String) -> Unit)? = null, followed: Boolean = true): Boolean {
  val uri = Uri.parse(url)
  val scheme = uri.scheme?.lowercase()
  val isInternalScheme = scheme in INTERNAL_SCHEMES
  if (isInternalScheme) {
    return false
  }

  try {
    if (scheme == "intent" && openInApp != null) {
      // A link that is itself a page of a site Nora shows is answered with that page, in the tab -- also
      // when it names the site's app, which would open it signed in. A link to anything else, such as
      // another app's own scheme, goes to that app as before; its fallback page is only for when it is missing.
      val requested = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
      val inApp = inAppUrlFor(requested.dataString, inAppHosts())
      if (inApp != null) {
        openInApp(inApp)
        return true
      }
    }
    val intent = if (scheme == "intent") {
      Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
        addCategory(Intent.CATEGORY_BROWSABLE)
        component = null
        selector = null
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    } else {
      Intent(Intent.ACTION_VIEW, uri).apply {
        if (scheme == "http" || scheme == "https") {
          addCategory(Intent.CATEGORY_BROWSABLE)
        }
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
    }
    val packageManager = context.packageManager
    val resolvedActivity = intent.resolveActivity(packageManager)
    if (resolvedActivity == null) {
      throw ActivityNotFoundException("No activity found to handle $url")
    }
    context.startActivity(intent)
    return true
  } catch (e: ActivityNotFoundException) {
    if (scheme == "intent") {
      try {
        val fallbackIntent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
        val fallbackUrl = fallbackIntent.getStringExtra("browser_fallback_url")
        val inApp = inAppUrlFor(fallbackUrl ?: fallbackIntent.dataString, inAppHosts())
        if (openInApp != null && inApp != null) {
          openInApp(inApp)
          return true
        }
        // A page of a site Nora shows that sends itself to its missing app on its own, as Threads does
        // as soon as it loads, stays as it is: its page is not handed to the system browser unasked.
        if (!followed && inApp != null) {
          return true
        }
        if (!fallbackUrl.isNullOrEmpty()) {
          context.startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl)).apply {
              val fallbackScheme = Uri.parse(fallbackUrl).scheme?.lowercase()
              if (fallbackScheme == "http" || fallbackScheme == "https") {
                addCategory(Intent.CATEGORY_BROWSABLE)
              }
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
          )
          return true
        }

        val dataUri = fallbackIntent.data
        if (dataUri != null) {
          context.startActivity(
            Intent(Intent.ACTION_VIEW, dataUri).apply {
              val dataScheme = dataUri.scheme?.lowercase()
              if (dataScheme == "http" || dataScheme == "https") {
                addCategory(Intent.CATEGORY_BROWSABLE)
              }
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
              `package` = null
              selector = null
              component = null
            }
          )
          return true
        }
      } catch (fallbackError: Exception) {
        fallbackError.printStackTrace()
      }
    }
    e.printStackTrace()
    return true
  } catch (e: Exception) {
    e.printStackTrace()
    return true
  }
}

class NoraView(context: Context, appContext: AppContext) : ExpoView(context, appContext) {
  private val onLoad by EventDispatcher()
  internal val onMessage by EventDispatcher()

  private var scriptOnStart = ""
  private var documentStartScript = ""
  private var documentStartScriptHandler: ScriptHandler? = null
  private var pageUrl = ""
  private var customView: View? = null
  private var contextMenuLinkUrl: String? = null
  private var contextMenuImageUrl: String? = null
  @Volatile
  private var contextMenuSuppressed = false

  internal fun setContextMenuSuppressed(suppressed: Boolean) {
    contextMenuSuppressed = suppressed
  }
  internal var userAgent: String? = null
  private var profileSet = false
  private var profileName = "default"
  /** Set by the app while the anonymous mode is on for the site this tab shows. */
  internal var openAppLinksInTab = false

  private var popupContainer: FrameLayout? = null
  private var popupWebView: WebView? = null

  private fun showPopup(popup: WebView) {
    dismissPopup()

    val container = FrameLayout(context).apply {
      setBackgroundColor(0xFF000000.toInt())
    }
    container.addView(
      popup,
      FrameLayout.LayoutParams(
        FrameLayout.LayoutParams.MATCH_PARENT,
        FrameLayout.LayoutParams.MATCH_PARENT
      )
    )

    val density = resources.displayMetrics.density
    val pad = (8 * density).toInt()
    val closeBtn = android.widget.TextView(context).apply {
      text = "X"
      textSize = 18f
      setTextColor(0xFFFFFFFF.toInt())
      setBackgroundColor(0x99000000.toInt())
      gravity = android.view.Gravity.CENTER
      setPadding(pad, pad, pad, pad)
      setOnClickListener { dismissPopup() }
    }
    val btnSize = (40 * density).toInt()
    val margin = (8 * density).toInt()
    val btnLp = FrameLayout.LayoutParams(
      btnSize,
      btnSize,
      android.view.Gravity.TOP or android.view.Gravity.END
    ).apply {
      topMargin = margin
      rightMargin = margin
    }
    container.addView(closeBtn, btnLp)

    addView(
      container,
      LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
    )
    popupContainer = container
    popupWebView = popup
  }

  // A popup that was never shown is never attached to a window, and View.post holds its
  // runnable until the view is attached, so destroying it through popup.post never ran and
  // leaked the WebView. Go through the main looper instead, still deferred so the popup is
  // not destroyed from inside its own WebViewClient callback.
  private fun destroyDetachedPopup(popup: WebView) {
    Handler(Looper.getMainLooper()).post { popup.destroy() }
  }

  private fun dismissPopup() {
    popupContainer?.let { removeView(it) }
    popupWebView?.destroy()
    popupContainer = null
    popupWebView = null
  }

  private var gestureDetector = GestureDetectorCompat(context, NoraGestureListener())
  private var lastTouchX = 0f
  private var lastTouchY = 0f

  // Resolving the context menu targets runs elementFromPoint in the page, which forces a
  // synchronous style+layout flush. On a busy site mid-scroll that costs ~70ms, and pages
  // whose scrolling is main-thread gated (x.com, whose own pointermove handler is
  // non-passive) turn that stall into a visible jump under the finger. So it is not run
  // on every touch: it is posted on the long-press delay and cancelled as soon as the
  // gesture turns out to be a scroll.
  private val touchHandler = Handler(Looper.getMainLooper())
  private var contextMenuPrewarm: Runnable? = null
  private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

  private fun cancelContextMenuPrewarm() {
    contextMenuPrewarm?.let { touchHandler.removeCallbacks(it) }
    contextMenuPrewarm = null
  }

  private fun scheduleContextMenuPrewarm() {
    cancelContextMenuPrewarm()
    val runnable = Runnable {
      contextMenuPrewarm = null
      if (!contextMenuSuppressed) {
        resolveContextMenuTargetsFromPoint()
      }
    }
    contextMenuPrewarm = runnable
    touchHandler.postDelayed(runnable, ViewConfiguration.getLongPressTimeout() / 2L)
  }

  internal val currentActivity: Activity?
    get() = appContext.currentActivity

  override fun onCreateContextMenu(menu: ContextMenu) {
    super.onCreateContextMenu(menu)
    if (contextMenuSuppressed) {
      return
    }

    val result = webView.getHitTestResult()
    val activity = currentActivity
    val fallbackUrl = result.getExtra()
    val linkUrl =
      contextMenuLinkUrl ?: if (
        result.getType() in arrayOf(WebView.HitTestResult.SRC_ANCHOR_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
      ) fallbackUrl else null
    val imageUrl =
      contextMenuImageUrl ?: if (
        result.getType() in arrayOf(WebView.HitTestResult.IMAGE_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
      ) fallbackUrl else null

    if ((linkUrl == null && imageUrl == null) || activity == null) {
      return
    }

    fun copyUrl(label: String, targetUrl: String) =
      object : MenuItem.OnMenuItemClickListener {
        override fun onMenuItemClick(item: MenuItem): Boolean {
          val clipboardManager = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
          val clipData = ClipData.newPlainText(label, targetUrl)
          clipboardManager.setPrimaryClip(clipData)
          return true
        }
      }

    fun openInNewTab(targetUrl: String, kind: String? = null) =
      object : MenuItem.OnMenuItemClickListener {
        override fun onMenuItemClick(item: MenuItem): Boolean {
          val payload = mutableMapOf<String, Any>("url" to targetUrl)
          if (kind != null) {
            payload["kind"] = kind
          }
          emit("new-tab", payload)
          return true
        }
      }

    fun openInProfile(targetUrl: String) =
      object : MenuItem.OnMenuItemClickListener {
        override fun onMenuItemClick(item: MenuItem): Boolean {
          emit("open-in-profile", mapOf("url" to targetUrl))
          return true
        }
      }

    if (
      result.getType() in arrayOf(WebView.HitTestResult.IMAGE_TYPE, WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
    ) {
      val imageTargetUrl = imageUrl ?: return
      val onDownload = object : MenuItem.OnMenuItemClickListener {
        override fun onMenuItemClick(item: MenuItem): Boolean {
          download(imageTargetUrl, null, "image/jpeg")
          return true
        }
      }

      menu.add(nouController.t("menu_saveImage")).setOnMenuItemClickListener(onDownload)
      menu.add(nouController.t("menu_openImageInNewTab")).setOnMenuItemClickListener(openInNewTab(imageTargetUrl, "image"))
      menu.add(nouController.t("menu_copyImageLink")).setOnMenuItemClickListener(copyUrl("image", imageTargetUrl))
      if (linkUrl != null && linkUrl != imageTargetUrl) {
        menu.add(nouController.t("menu_openInNewTab")).setOnMenuItemClickListener(openInNewTab(linkUrl))
        menu.add(nouController.t("menu_openInProfile")).setOnMenuItemClickListener(openInProfile(linkUrl))
        menu.add(nouController.t("menu_copyLink")).setOnMenuItemClickListener(copyUrl("link", linkUrl))
      }
    } else if (result.getType() == WebView.HitTestResult.SRC_ANCHOR_TYPE && linkUrl != null) {
      menu.add(nouController.t("menu_openInNewTab")).setOnMenuItemClickListener(openInNewTab(linkUrl))
      menu.add(nouController.t("menu_openInProfile")).setOnMenuItemClickListener(openInProfile(linkUrl))
      menu.add(nouController.t("menu_copyLink")).setOnMenuItemClickListener(copyUrl("link", linkUrl))
    }
  }

  private fun prepareContextMenuTargets() {
    val result = webView.getHitTestResult()
    when (result.getType()) {
      WebView.HitTestResult.SRC_ANCHOR_TYPE -> contextMenuLinkUrl = result.getExtra()
      WebView.HitTestResult.IMAGE_TYPE -> contextMenuImageUrl = result.getExtra()
      WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> contextMenuImageUrl = result.getExtra()
    }

    val handler =
      Handler(Looper.getMainLooper()) { msg ->
        val data = msg.data
        val linkUrl = data?.getString("url")?.takeIf { it.isNotEmpty() }
        val imageUrl = data?.getString("src")?.takeIf { it.isNotEmpty() }
        if (linkUrl != null) {
          contextMenuLinkUrl = linkUrl
        }
        if (imageUrl != null) {
          contextMenuImageUrl = imageUrl
        }
        false
      }
    webView.requestFocusNodeHref(handler.obtainMessage())
    resolveContextMenuTargetsFromPoint()
  }

  private fun resolveContextMenuTargetsFromPoint() {
    val x = lastTouchX
    val y = lastTouchY
    val script =
      """
        (() => {
          const dpr = window.devicePixelRatio || 1;
          const element =
            document.elementFromPoint($x / dpr, $y / dpr) ||
            document.elementFromPoint($x, $y);
          const image = element?.closest?.('img');
          const link = element?.closest?.('a[href]');
          return JSON.stringify([
            link ? link.href : '',
            image ? (image.currentSrc || image.src || '') : ''
          ]);
        })();
      """.trimIndent()

    webView.evaluateJavascript(script) { result ->
      try {
        val payload = JSONTokener(result).nextValue() as? String ?: return@evaluateJavascript
        val targets = JSONArray(payload)
        val linkUrl = targets.optString(0).takeIf { it.isNotEmpty() }
        val imageUrl = targets.optString(1).takeIf { it.isNotEmpty() }
        if (linkUrl != null) {
          contextMenuLinkUrl = linkUrl
        }
        if (imageUrl != null) {
          contextMenuImageUrl = imageUrl
        }
      } catch (_: Throwable) {
      }
    }
  }

  // A touch sample carries one bridge message per ACTION_MOVE (~120/s), so it is only
  // emitted when a setting actually consumes it. Both header auto-hide settings default
  // to off, which left every scroll paying for messages the JS side discarded.
  internal var scrollEventsEnabled = false

  inner class NoraGestureListener : GestureDetector.SimpleOnGestureListener() {
    override fun onDown(e: MotionEvent): Boolean = true

    override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
      if (!scrollEventsEnabled) {
        return true
      }
      var dy = distanceY
      if (e1 != null) {
        // Screen coordinates: showing or hiding the toolbar moves the webview, which shifts
        // view-relative y by the toolbar height mid-drag and flips the toolbar back.
        dy = e2.rawY - e1.rawY
      }
      emit("scroll", mapOf("dy" to dy, "y" to webView.scrollY))
      return true
    }
  }

  // Pull down from the top of the page to reload, like Chrome and Firefox do. Off unless
  // the setting turns it on, so pages with their own overscroll gestures are untouched.
  private var pullToRefreshEnabled = false
  // Set by the page while a gesture of its own (holding a video to speed it up) owns the
  // touch; the refresh layout would otherwise steal it on a slight downward drift.
  private var pullToRefreshSuspended = false
  private val swipeRefresh = NoraSwipeRefreshLayout(context)

  // The refresh layout only sees the WebView's own scroll position, which stays at 0 on
  // pages that scroll an inner element instead of the document. The page reports where
  // those scrolled away elements are (through NouJsInterface, so off the main thread),
  // and a drag starting inside one of them is left to the page.
  @Volatile
  private var scrolledRegions: List<RectF> = emptyList()
  private var lastDownX = 0f
  private var lastDownY = 0f

  internal fun setScrolledRegions(json: String) {
    scrolledRegions = try {
      val array = JSONArray(json)
      (0 until array.length()).mapNotNull { i ->
        val rect = array.optJSONArray(i) ?: return@mapNotNull null
        RectF(
          rect.optDouble(0).toFloat(),
          rect.optDouble(1).toFloat(),
          rect.optDouble(2).toFloat(),
          rect.optDouble(3).toFloat()
        )
      }
    } catch (e: Exception) {
      emptyList()
    }
  }

  private fun isInScrolledRegion(x: Float, y: Float) = scrolledRegions.any { it.contains(x, y) }

  // Runs before the refresh layout's own interception, so the callback below can ask
  // where this gesture started rather than where the last one did.
  override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
    if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
      lastDownX = ev.x
      lastDownY = ev.y
    }
    return super.onInterceptTouchEvent(ev)
  }

  internal fun setPullToRefresh(enabled: Boolean) {
    pullToRefreshEnabled = enabled
    updateSwipeRefreshEnabled()
    if (!enabled) {
      swipeRefresh.isRefreshing = false
    }
  }

  // Background tabs stay mounted behind the active one at full size, and a transparent
  // view still counts as visible to Chromium, so each one would keep running animation
  // frames, timers and video at full speed. Pausing marks the page hidden instead, which
  // keeps its DOM and scroll position but lets Chromium throttle it.
  private var active = true

  internal fun setActive(value: Boolean) {
    if (active == value) {
      return
    }
    active = value
    if (value) {
      webView.onResume()
    } else {
      webView.onPause()
    }
  }

  internal fun setPullToRefreshSuspended(suspended: Boolean) {
    post {
      pullToRefreshSuspended = suspended
      updateSwipeRefreshEnabled()
    }
  }

  private fun updateSwipeRefreshEnabled() {
    swipeRefresh.isEnabled = pullToRefreshEnabled && customView == null && !pullToRefreshSuspended
  }

  internal val webView =
    NouWebView(context).apply {
      layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
      webViewClient =
        object : WebViewClient() {
          override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
            if (nouController.settings.redirectToOldReddit && url.startsWith("https://www.reddit.com/")) {
              load(url.replace("www.reddit.com", "old.reddit.com"))
              return
            }
            if (isDesktopFacebookUrl(url) && (Uri.parse(url).host == "m.facebook.com" || view.settings.userAgentString != uaLinux)) {
              load(desktopFacebookUrl(url))
              return
            }
            if (shouldRedirectFacebookToMobile(pageUrl, url, userAgent?.contains(" Mobile ") == false)) {
              load(url.replace("www", "m"))
              return
            }
            pageUrl = url
            onLoad(
              mapOf(
                "canGoBack" to view.canGoBack(),
                "url" to pageUrl
              )
            )
          }

          override fun onPageFinished(view: WebView, url: String) {
            swipeRefresh.isRefreshing = false
          }

          override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            pageUrl = url
            scrolledRegions = emptyList()
            if (Uri.parse(url).host in GOOGLE_AUTH_HOSTS) {
              evaluateJavascript(OAUTH_SHIM_SCRIPT, null)
            }
            // Only a fallback: when the WebView supports document start scripts the
            // guard is already installed before any page script has run.
            if (documentStartScriptHandler == null) {
              evaluateJavascript(documentStartSource(), null)
            }
            evaluateJavascript(scriptOnStart, null)
          }

          override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            if (!request.isForMainFrame && nouController.shouldBlockRequestHost(request.url.host, Uri.parse(pageUrl).host)) {
              return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            if (request.url.scheme == "http" && !nouController.settings.allowHttpWebsite) {
              return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
            }
            return null
          }

          override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
            return overrideUrlLoading(view, url, false)
          }

          /**
           * [allowInApp]: this is the person's own tap, on the page itself, with the anonymous mode on --
           * the one place a link that asks for an app is answered by opening its page in the tab.
           */
          private fun overrideUrlLoading(view: WebView, url: String, allowInApp: Boolean, followed: Boolean = true): Boolean {
            if (url.startsWith("http://") && !nouController.settings.allowHttpWebsite) {
              showHttpBlockedPage(url)
              return true
            }
            if (nouController.settings.redirectToOldReddit && url.startsWith("https://www.reddit.com/")) {
              load(url.replace("www.reddit.com", "old.reddit.com"))
              return true
            }
            val redirectedUrl = redirectFacebookUrl(url)
            if (redirectedUrl != null && !pageUrl.startsWith(redirectedUrl)) {
              load(redirectedUrl)
              return true
            }
            if (isDesktopFacebookUrl(url) && (Uri.parse(url).host == "m.facebook.com" || view.settings.userAgentString != uaLinux)) {
              load(desktopFacebookUrl(url))
              return true
            }
            if (shouldRedirectFacebookToMobile(pageUrl, url, userAgent?.contains(" Mobile ") == false)) {
              load(url.replace("www", "m"))
              return true
            }
            return shouldNoraOverrideUrlLoading(
              view,
              url,
              if (allowInApp) { target -> view.post { view.loadUrl(target) } } else null,
              followed,
            )
          }

          override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            // Not a frame of the page, which a page can send anywhere without being asked, and not without
            // a tap. Without the anonymous mode an app link is handled as it always was.
            val allowInApp = request.isForMainFrame && request.hasGesture() && openAppLinksInTab
            return overrideUrlLoading(view, request.url.toString(), allowInApp, request.hasGesture())
          }

          override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            log("onRenderProcessGone crash: ${detail.didCrash()}")
            view.post {
              load(pageUrl)
            }
            return true
          }
        }

      webChromeClient = object : WebChromeClient() {
        override fun getDefaultVideoPoster(): Bitmap {
          return Bitmap.createBitmap(intArrayOf(Color.BLACK), 1, 1, Bitmap.Config.ARGB_8888)
        }

        override fun onReceivedIcon(view: WebView, icon: Bitmap) {
          emit("icon", "")
        }

        override fun onReceivedTitle(view: WebView, title: String) {
          onLoad(
            mapOf(
              "canGoBack" to view.canGoBack(),
              "title" to title
            )
          )
        }

        override fun onPermissionRequest(request: PermissionRequest) {
          val activity = currentActivity
          if (activity == null) {
            request.deny()
            return
          }

          val resources = request.resources
          val permissionsToRequest = mutableListOf<String>()

          if (resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)) {
            permissionsToRequest.add(android.Manifest.permission.RECORD_AUDIO)
          }
          if (resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) {
            permissionsToRequest.add(android.Manifest.permission.CAMERA)
          }

          if (permissionsToRequest.isEmpty()) {
            request.grant(resources)
            return
          }

          // In a real production app, we should handle the result of the permission request.
          // For now, we request them and grant the WebView request.
          // Note: If the user denies, the WebView will just fail to get the stream.
          activity.requestPermissions(permissionsToRequest.toTypedArray(), 101)
          request.grant(resources)
        }

        override fun onJsBeforeUnload(view: WebView, url: String, message: String, result: JsResult): Boolean {
          result.confirm()
          return true
        }

        override fun onShowCustomView(view: View, cllback: CustomViewCallback) {
          customView = view
          swipeRefresh.isEnabled = false
          val activity = currentActivity
          if (activity == null) {
            return
          }
          val window = activity.window
          (window.decorView as FrameLayout).addView(
            view,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
          )

          // https://stackoverflow.com/a/64828067
          val controller = WindowCompat.getInsetsController(window, window.decorView)
          controller.hide(WindowInsetsCompat.Type.systemBars())
          controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        override fun onHideCustomView() {
          hideCustomView()
        }

        override fun onShowFileChooser(
          view: WebView,
          callback: ValueCallback<Array<Uri>>,
          params: WebChromeClient.FileChooserParams
        ): Boolean {
          // https://stackoverflow.com/a/62625964
          nouController.setFileChooserCallback(callback)
          // params.createIntent() only honors acceptTypes[0] and passes it to
          // setType() verbatim, so extension based accept lists (`.jpg,.png`,
          // used by desktop Facebook and Reddit) leave the picker with an
          // invalid MIME filter and it shows no photos or videos at all.
          // Keep the platform intent so save and folder picker modes retain
          // their actions and extras, but replace its MIME filter with the
          // full, normalized list.
          val mimeTypes = normalizeAcceptTypes(params.acceptTypes)
          val intent = params.createIntent().apply {
            type = if (mimeTypes.size == 1) mimeTypes[0] else "*/*"
            removeExtra(Intent.EXTRA_MIME_TYPES)
            if (mimeTypes.size > 1) {
              putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes)
            }
          }
          val activity = currentActivity
          activity?.startActivityForResult(intent, 0)
          return true
        }

        override fun onCreateWindow(
          view: WebView,
          isDialog: Boolean,
          isUserGesture: Boolean,
          resultMsg: android.os.Message
        ): Boolean {
          val newWebView = NouWebView(view.getContext())
          if (profileName != "default" && WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            try {
              WebViewCompat.setProfile(newWebView, profileName)
            } catch (e: Exception) {
              log("set popup profile failed: ${e.message}")
            }
          }
          installGoogleOAuthShim(newWebView)
          // A popup starts out as its own realm the opener can run scripts in,
          // so it needs the guard as much as a tab does.
          installDocumentStartScript(newWebView)
          newWebView.settings.userAgentString = view.settings.userAgentString
          var decided = false

          // A web link the person left to the system browser: the popup is of no use, whether it is
          // still the blank placeholder or has just started loading the real URL.
          fun handOffToSystemBrowser(popup: WebView, url: String): Boolean {
            val uri = Uri.parse(url)
            if (uri.scheme?.lowercase() !in setOf("http", "https") || isGoogleOAuthPopupUrl(url) || !shouldOpenInSystemBrowser(uri)) {
              return false
            }
            decided = true
            popup.stopLoading()
            if (popupWebView === popup) dismissPopup() else destroyDetachedPopup(popup)
            openInSystemBrowser(popup.context, uri)
            return true
          }

          newWebView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(popup: WebView, url: String, favicon: Bitmap?) {
              if (Uri.parse(url).host in GOOGLE_AUTH_HOSTS) {
                popup.evaluateJavascript(OAUTH_SHIM_SCRIPT, null)
              }
              if (decided) return
              // about:blank is a transient placeholder; JS will navigate the popup
              // via window.opener. Attach as overlay so it stays alive, but defer the
              // commit until a real URL appears.
              if (url == "about:blank" || url.startsWith("about:")) {
                if (popupWebView !== popup) showPopup(popup)
                return
              }
              if (handOffToSystemBrowser(popup, url)) return
              decided = true
              if (isGoogleOAuthPopupUrl(url)) {
                if (popupWebView !== popup) showPopup(popup)
              } else {
                popup.stopLoading()
                if (popupWebView === popup) dismissPopup() else destroyDetachedPopup(popup)
                log("new-tab: $url")
                emit("new-tab", mapOf("url" to url))
              }
            }

            override fun shouldOverrideUrlLoading(popup: WebView, url: String): Boolean {
              return shouldNoraOverrideUrlLoading(popup, url)
            }

            override fun shouldOverrideUrlLoading(popup: WebView, request: WebResourceRequest): Boolean {
              val url = request.url.toString()
              if (request.isForMainFrame && handOffToSystemBrowser(popup, url)) return true
              return shouldOverrideUrlLoading(popup, url)
            }
          }

          newWebView.webChromeClient = object : WebChromeClient() {
            override fun onCloseWindow(window: WebView) {
              if (popupWebView === window) {
                dismissPopup()
              }
            }
          }

          val transport = resultMsg.obj as WebView.WebViewTransport
          transport.setWebView(newWebView)
          resultMsg.sendToTarget()
          return true
        }
      }

      setDownloadListener(
        object : DownloadListener {
          override fun onDownloadStart(
            url: String,
            userAgent: String,
            contentDisposition: String,
            mimeType: String,
            contentLength: Long
          ) {
            var fileName: String? = null
            if (contentDisposition != "") {
              fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            }
            if (url.startsWith("blob:")) {
              val name = fileName?.let(JSONObject::quote) ?: "null"
              evaluateJavascript(
                "window.Nora?.downloadBlob(${JSONObject.quote(url)}, $name, ${JSONObject.quote(mimeType)})",
                null
              )
            } else {
              download(url, fileName, mimeType)
            }
          }
        }
      )
      setOnTouchListener { v, event ->
        gestureDetector.onTouchEvent(event)
        when (event.actionMasked) {
          MotionEvent.ACTION_DOWN -> {
            lastTouchX = event.x
            lastTouchY = event.y
            contextMenuLinkUrl = null
            contextMenuImageUrl = null
            contextMenuSuppressed = false
            scheduleContextMenuPrewarm()
            v.requestFocus()
          }
          MotionEvent.ACTION_MOVE -> {
            val moved = Math.hypot(
              (event.x - lastTouchX).toDouble(),
              (event.y - lastTouchY).toDouble()
            )
            if (moved > touchSlop) {
              cancelContextMenuPrewarm()
            }
          }
          MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> {
            cancelContextMenuPrewarm()
          }
        }
        false
      }
      setOnLongClickListener {
        if (!contextMenuSuppressed) {
          prepareContextMenuTargets()
        }
        false
      }
    }

  private fun layoutChildren() {
    val childWidth = width - paddingLeft - paddingRight
    val childHeight = height - paddingTop - paddingBottom
    if (childWidth <= 0 || childHeight <= 0) {
      return
    }
    val childWidthSpec = MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.EXACTLY)
    val childHeightSpec = MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.EXACTLY)
    for (i in 0 until childCount) {
      val child = getChildAt(i)
      if (child.visibility != GONE) {
        child.measure(childWidthSpec, childHeightSpec)
        child.layout(
          paddingLeft,
          paddingTop,
          paddingLeft + childWidth,
          paddingTop + childHeight
        )
      }
    }
  }

  override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
    super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    val childWidthSpec = MeasureSpec.makeMeasureSpec(
      measuredWidth - paddingLeft - paddingRight,
      MeasureSpec.EXACTLY
    )
    val childHeightSpec = MeasureSpec.makeMeasureSpec(
      measuredHeight - paddingTop - paddingBottom,
      MeasureSpec.EXACTLY
    )
    for (i in 0 until childCount) {
      val child = getChildAt(i)
      if (child.visibility != GONE) {
        child.measure(childWidthSpec, childHeightSpec)
      }
    }
  }

  override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
    super.onLayout(changed, left, top, right, bottom)
    layoutChildren()
  }

  // On RN 0.85 + Fabric, requestLayout() from imperatively-added children
  // (the WebView, popup container, etc.) can be swallowed because Yoga only
  // manages views it owns. Re-layout children on the next frame.
  override fun requestLayout() {
    super.requestLayout()
    post { layoutChildren() }
  }

  init {
    val nightMode = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
      Configuration.UI_MODE_NIGHT_YES
    swipeRefresh.apply {
      layoutParams = LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)
      isEnabled = false
      setColorSchemeColors(if (nightMode) 0xFFE4E4E7.toInt() else 0xFF3F3F46.toInt())
      setProgressBackgroundColorSchemeColor(if (nightMode) 0xFF27272A.toInt() else 0xFFFFFFFF.toInt())
      setOnRefreshListener { webView.reload() }
      setOnChildScrollUpCallback { _, _ ->
        webView.canScrollVertically(-1) || isInScrolledRegion(lastDownX, lastDownY)
      }
    }
    swipeRefresh.addView(webView)
    addView(swipeRefresh)
    nouController.register(this)

    val activity = currentActivity
    activity?.registerForContextMenu(webView)

    webView.addJavascriptInterface(NouJsInterface(context, this), "NoraI")
    installGoogleOAuthShim(webView)
    webView.setFindListener { active, total, isDone ->
      if (isDone) {
        emit("find-result", mapOf("active" to if (total > 0) active + 1 else 0, "total" to total))
      }
    }

    // some websites have `padding-bottom: env(safe-area-inset-bottom)`, this set it to 0
    // but we need to preserve the IME inset so the WebView resizes when the keyboard opens
    ViewCompat.setOnApplyWindowInsetsListener(webView) { v, insets ->
      val imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
      val newInsets = WindowInsetsCompat.Builder()
        .setInsets(WindowInsetsCompat.Type.ime(), imeInsets)
        .build()
      ViewCompat.onApplyWindowInsets(v, newInsets)
      newInsets
    }
  }

  fun load(url: String) {
    if (url == "" || url == "about:blank") return
    if (handleExternalAppUrl(context, url)) {
      return
    }
    if (url.startsWith("http://") && !nouController.settings.allowHttpWebsite) {
      showHttpBlockedPage(url)
      return
    }
    pageUrl = url
    var ua = userAgent
    if (isDesktopFacebookUrl(url) || isTikTokUrl(url)) {
      ua = uaLinux
    } else if (ua == null) {
      ua = uaAndroid
    }
    webView.settings.setUserAgentString(ua)
    webView.loadUrl(url)
  }

  private fun showHttpBlockedPage(url: String) {
    val title = nouController.t("httpBlocked_title")
    val body = nouController.t("httpBlocked_body")
    val html = """
      <html>
      <head>
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <style>
          body { font-family: sans-serif; padding: 32px 24px; margin: 0; background: #18181b; color: #e4e4e7; }
          h2 { color: #f4f4f5; margin-bottom: 12px; }
          p { line-height: 1.6; color: #a1a1aa; }
          .url { word-break: break-all; background: #27272a; padding: 8px 12px; border-radius: 8px; font-size: 13px; color: #71717a; margin: 16px 0; }
        </style>
      </head>
      <body>
        <h2>$title</h2>
        <div class="url">$url</div>
        <p>$body</p>
      </body>
      </html>
    """.trimIndent()
    webView.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
  }

  fun setProfile(profile: String) {
    profileName = profile
    if (profileSet) return
    if (profile == "default") return
    try {
      if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
        WebViewCompat.setProfile(webView, profile)
      }
    } catch (e: Exception) {
      log("setProfile failed: ${e.message}")
    }
    profileSet = true
  }

  fun setTextZoom(zoom: Int) {
    webView.settings.textZoom = zoom
  }

  fun setScriptOnStart(script: String) {
    scriptOnStart = script
  }

  /**
   * Runs [script] before any page script on every navigation, so a page can't
   * capture the globals it overrides. Takes effect on the next page load.
   */
  fun setScriptOnDocumentStart(script: String) {
    if (script == documentStartScript) {
      return
    }
    documentStartScript = script
    refreshDocumentStartScript()
  }

  private fun hideCustomView() {
    val activity = currentActivity
    if (activity == null || customView == null) {
      return
    }
    val window = activity.window
    (window.decorView as FrameLayout).removeView(customView)
    customView = null
    updateSwipeRefreshEnabled()
    val controller = WindowCompat.getInsetsController(window, window.decorView)
    controller.show(WindowInsetsCompat.Type.systemBars())
  }

  /**
   * Called when React drops the view, i.e. the tab is closed or remounted. Without this the
   * WebView, whose JS bridge points back at this view, keeps the page alive and running
   * until the GC happens to collect it, which can take minutes or never happen.
   */
  internal fun destroy() {
    cancelContextMenuPrewarm()
    hideCustomView()
    dismissPopup()
    nouController.unregister(this)
    documentStartScriptHandler?.remove()
    documentStartScriptHandler = null
    webView.stopLoading()
    webView.removeJavascriptInterface("NoraI")
    swipeRefresh.removeView(webView)
    webView.destroy()
  }

  /** Re-installs the document start script, picking up the current exceptions. */
  internal fun refreshDocumentStartScript() {
    documentStartScriptHandler?.remove()
    documentStartScriptHandler = installDocumentStartScript(webView)
  }

  /**
   * The guards and the per-site ad blocking exceptions share the one document
   * start script the WebView takes. Each part is self-contained, so they are
   * separated by a newline and a semicolon: a part ending in an expression must
   * not swallow the next one.
   */
  private fun documentStartSource(): String {
    return listOf(nouController.blocklistExclusionsScript(), documentStartScript)
      .filter { it.isNotEmpty() }
      .joinToString("\n;\n")
  }

  private fun installDocumentStartScript(target: WebView): ScriptHandler? {
    if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
      return null
    }
    return try {
      WebViewCompat.addDocumentStartJavaScript(target, documentStartSource(), setOf("*"))
    } catch (e: Exception) {
      log("addDocumentStartJavaScript failed: ${e.message}")
      null
    }
  }

  fun download(url: String, fileName: String?, mimeType: String?) {
    val activity = currentActivity
    if (activity == null) {
      return
    }

    // DownloadManager can't read `blob:` URLs, the page has to hand us the bytes.
    // The blob knows its own type, so `mimeType` is left out on purpose here.
    if (url.startsWith("blob:")) {
      val name = fileName?.let(JSONObject::quote) ?: "null"
      webView.evaluateJavascript(
        "window.Nora?.downloadBlob(${JSONObject.quote(url)}, $name)",
        null
      )
      return
    }

    if (nouController.settings.askDownloadDestination || nouController.settings.downloadFolder.isNotEmpty()) {
      downloadToDocument(activity, url, fileName, mimeType)
      return
    }

    CoroutineScope(Dispatchers.IO).launch {
      try {
        val uri = Uri.parse(url)
        val request = DownloadManager.Request(uri)
        // A name from Content-Disposition is the server's own, leave it alone.
        val name = fileName ?: normalizeFileName(uri.getLastPathSegment() ?: "download", mimeType)
        request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
        request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        val downloadManager = activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        downloadManager.enqueue(request)
        activity.runOnUiThread {
          Toast.makeText(context, nouController.t("toast_downloadStarted"), Toast.LENGTH_LONG).show()
        }
      } catch (e: Exception) {
        activity.runOnUiThread {
          Toast.makeText(context, nouController.t("toast_downloadFailed"), Toast.LENGTH_LONG).show()
        }
      }
    }
  }

  // Saves where the settings say: a file the user names in the save dialog, or one created in
  // the download folder. Null when the user dismissed the dialog.
  private suspend fun createDownloadDocument(
    activity: Activity,
    fileName: String,
    mimeType: String,
    settings: NoraSettings = nouController.settings,
  ): Uri? {
    if (!settings.askDownloadDestination && settings.downloadFolder.isNotEmpty()) {
      return withContext(Dispatchers.IO) {
        NoraDownloadFolder.createDocument(context, settings.downloadFolder, fileName, mimeType)
      }
    }
    return nouController.downloadPicker.createDocument(activity, fileName, mimeType)
  }

  private fun downloadToDocument(activity: Activity, url: String, fileName: String?, mimeType: String?) {
    CoroutineScope(Dispatchers.Main).launch {
      var destination: Uri? = null
      try {
        val name = fileName ?: normalizeFileName(Uri.parse(url).lastPathSegment ?: "download", mimeType)
        val type = systemMimeTypes.mimeTypeFor(name.substringAfterLast('.', "").lowercase()) ?: mimeType
          ?: "application/octet-stream"
        val userAgent = webView.settings.userAgentString
        val referer = webView.url
        val cookies = if (WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
          WebViewCompat.getProfile(webView).cookieManager
        } else {
          CookieManager.getInstance()
        }
        val uri = createDownloadDocument(activity, name, type) ?: return@launch
        destination = uri
        Toast.makeText(context, nouController.t("toast_savingFile"), Toast.LENGTH_LONG).show()
        withContext(Dispatchers.IO) {
          copyDownload(url, userAgent, referer, cookies::getCookie) {
            context.contentResolver.openOutputStream(uri, "w")
              ?: throw IOException("Cannot open download destination")
          }
        }
        Toast.makeText(context, nouController.t("toast_fileSaved"), Toast.LENGTH_LONG).show()
        notifySaved(uri, name, type)
      } catch (error: Exception) {
        destination?.let { uri -> withContext(Dispatchers.IO) { deleteDownloadDocument(uri) } }
        if (error is CancellationException) throw error
        log("Download failed: ${error.message}")
        Toast.makeText(context, nouController.t(NoraDownloadFolder.failureMessageKey(error)), Toast.LENGTH_LONG).show()
      }
    }
  }

  private fun deleteDownloadDocument(uri: Uri) {
    try {
      DocumentsContract.deleteDocument(context.contentResolver, uri)
    } catch (error: Exception) {
      log("Could not remove incomplete download: ${error.message}")
    }
  }

  // DownloadManager posts its own notification; other saves need one as well.
  private fun notifySaved(uri: Uri, fileName: String, mimeType: String?) {
    try {
      // A file in the download folder is covered by the folder's own persisted grant.
      if (DocumentsContract.isDocumentUri(context, uri) && !DocumentsContract.isTreeUri(uri)) {
        // The notification can outlive the activity's temporary URI grant. If a
        // provider cannot persist read access, keep the save but skip the notification.
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        manager.createNotificationChannel(
          NotificationChannel(
            SAVED_FILE_CHANNEL_ID,
            nouController.t("toast_fileSaved"),
            NotificationManager.IMPORTANCE_LOW
          )
        )
      }

      val viewIntent = Intent(Intent.ACTION_VIEW).apply {
        setDataAndType(uri, mimeType)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      var flags = PendingIntent.FLAG_UPDATE_CURRENT
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        flags = flags or PendingIntent.FLAG_IMMUTABLE
      }
      val notificationId = uri.hashCode()
      val pendingIntent = PendingIntent.getActivity(context, notificationId, viewIntent, flags)

      val notification = NotificationCompat.Builder(context, SAVED_FILE_CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_download_done)
        .setContentTitle(nouController.t("toast_fileSaved"))
        .setContentText(fileName)
        .setContentIntent(pendingIntent)
        .setAutoCancel(true)
        .build()
      manager.notify(notificationId, notification)
    } catch (e: Exception) {
      // The file is already saved, a missing notification must not fail the download.
      e.printStackTrace()
    }
  }

  fun saveFile(content: String, _fileName: String, _mimeType: String?) {
    val activity = currentActivity
    if (activity == null) {
      return
    }

    val settings = nouController.settings
    val toDocument = settings.askDownloadDestination || settings.downloadFolder.isNotEmpty()
    CoroutineScope(Dispatchers.IO).launch {
      val resolver = context.contentResolver
      var uri: Uri? = null
      try {
        val bytes = Base64.getDecoder().decode(content)
        var mimeType = _mimeType
        var detected = true
        if (mimeType == null || mimeType == "application/octet-stream") {
          mimeType = try {
            Tika().detect(bytes)
          } catch (e: Throwable) {
            // Tika's XML detection needs javax.xml.stream, which Android lacks.
            e.printStackTrace()
            detected = false
            val ext = _fileName.substringAfterLast('.', "").lowercase()
            systemMimeTypes.mimeTypeFor(ext) ?: "application/octet-stream"
          }
        }
        val fileName = normalizeFileName(_fileName, mimeType, detected)
        if (toDocument) {
          val destination = createDownloadDocument(
            activity, fileName, mimeType ?: "application/octet-stream", settings
          ) ?: return@launch
          uri = destination
          val output = resolver.openOutputStream(destination, "w")
            ?: throw IOException("Cannot open download destination")
          output.use { it.write(bytes) }
          activity.runOnUiThread {
            Toast.makeText(context, nouController.t("toast_fileSaved"), Toast.LENGTH_LONG).show()
          }
          notifySaved(destination, fileName, mimeType)
          return@launch
        }
        val contentValues = ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
          put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
          put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }

        uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
        uri?.let {
          resolver.openOutputStream(it)?.use { outputStream ->
            outputStream.write(bytes)
          }
        }
        activity.runOnUiThread {
          Toast.makeText(context, nouController.t("toast_downloadSucceeded"), Toast.LENGTH_LONG).show()
        }
        uri?.let { notifySaved(it, fileName, mimeType) }
      } catch (e: Exception) {
        e.printStackTrace()
        uri?.let {
          if (toDocument) deleteDownloadDocument(it) else resolver.delete(it, null, null)
        }
        if (e is CancellationException) throw e
        activity.runOnUiThread {
          Toast.makeText(context, nouController.t(NoraDownloadFolder.failureMessageKey(e)), Toast.LENGTH_LONG).show()
        }
      }
    }
  }

  fun log(msg: String) {
    emit("[kotlin]", msg)
  }

  fun emit(type: String, data: Any) {
    val payload = mapOf("type" to type, "data" to data)
    onMessage(mapOf("payload" to payload))
  }
}
