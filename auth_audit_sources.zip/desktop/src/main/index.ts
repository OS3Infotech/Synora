import { app, shell, BrowserWindow, screen, session, Menu, clipboard } from 'electron'
import { attachDownloadHandler } from './lib/download'
import { join } from 'path'
import { electronApp, optimizer, is } from '@electron-toolkit/utils'
import icon from '../../resources/icon.png?asset'
import { setMainWindow } from './lib/main-window'
import { bindDeeplink } from './lib/deeplink'
import { genDesktopFile } from './lib/linux'
import { checkForUpdate } from './lib/auto-update'
import { initMainChannel } from './ipc/main'
import { uiClient } from './ipc/ui'
import { getUserAgent } from '@/lib/useragent'
import { isHttpUrl, normalizeExternalTargetUrl, shouldOpenInSystemBrowser } from './lib/link-handling'
import { FIREFOX_UA, isGoogleAuthUrl, isOAuthPopupUrl, setupGoogleAuthSession } from './lib/google-auth-popup'
import { attachWebRtcProtection } from './lib/webrtc'
import { readImage } from './lib/image-preview'
import { randomUUID } from 'node:crypto'
import { attachGuestShortcuts } from './lib/shortcuts'
import { attachGuestNotifications } from './lib/notifications'
import { exportApplication } from './lib/xdg-activation'
import { isWatchPage, registerWatchMediaScheme, setupWatch } from './lib/watch'

app.userAgentFallback = getUserAgent(process.platform, true)

if (
  process.env.DISABLE_GPU === '1' ||
  process.env.ELECTRON_DISABLE_GPU === '1' ||
  (process.platform === 'linux' && process.env.DISPLAY?.startsWith('localhost'))
) {
  app.disableHardwareAcceleration()
  app.commandLine.appendSwitch('disable-gpu')
}

function attachContextMenu(webContents: Electron.WebContents, ownerWindow: BrowserWindow): void {
  webContents.on('context-menu', (_event, params) => {
    const hasSelection = params.selectionText.trim().length > 0
    const hasMisspelling = params.isEditable && params.misspelledWord.length > 0
    const can = (type: keyof Electron.EditFlags): boolean => params.editFlags[type]
    const menuTemplate: Electron.MenuItemConstructorOptions[] = [
      ...params.dictionarySuggestions.map((suggestion) => ({
        label: suggestion,
        visible: hasMisspelling,
        click: () => webContents.replaceMisspelling(suggestion),
      })),
      { type: 'separator' },
      {
        role: 'cut',
        visible: params.isEditable,
        enabled: can('canCut'),
      },
      {
        role: 'copy',
        visible: params.isEditable || hasSelection,
        enabled: can('canCopy') || hasSelection,
      },
      {
        role: 'paste',
        visible: params.isEditable,
        enabled: can('canPaste'),
      },
      { type: 'separator' },
      {
        label: 'Copy Link',
        visible: params.linkURL.length > 0 && params.mediaType === 'none',
        click: () => {
          clipboard.write({
            bookmark: params.linkText,
            text: params.linkURL,
          })
        },
      },
      {
        label: 'Open in new tab',
        visible: isHttpUrl(params.linkURL),
        click: () => {
          uiClient.openTab(params.linkURL, webContents.id)
        },
      },
      {
        label: 'Open in profile',
        visible: isHttpUrl(params.linkURL),
        click: () => {
          uiClient.openLinkInProfile(params.linkURL)
        },
      },
      { type: 'separator' },
      {
        label: 'View image',
        visible: params.mediaType === 'image' && /^(https?:|data:image\/|blob:)/i.test(params.srcURL),
        click: async () => {
          const id = randomUUID()
          uiClient.showImagePreview(id)
          try {
            const dataUrl = await readImage(webContents, params.srcURL, params.frame)
            uiClient.updateImagePreview(id, dataUrl)
          } catch {
            uiClient.updateImagePreview(id, null)
          }
        },
      },
      {
        label: 'Copy Image',
        visible: params.mediaType === 'image',
        click: () => {
          webContents.copyImageAt(params.x, params.y)
        },
      },
      {
        label: 'Save Image As…',
        visible: params.mediaType === 'image' && params.srcURL.length > 0,
        click: () => {
          webContents.downloadURL(params.srcURL)
        },
      },
      { type: 'separator' },
      {
        label: 'Open in default browser',
        visible: isHttpUrl(params.linkURL),
        click: () => {
          shell.openExternal(params.linkURL)
        },
      },
    ]

    const visibleItems = menuTemplate
      .filter((item) => item.visible !== false)
      .filter((item, index, items) => {
        if (item.type !== 'separator') {
          return true
        }
        return (
          index > 0 &&
          index < items.length - 1 &&
          items[index - 1].type !== 'separator' &&
          items.slice(index + 1).some((item) => item.type !== 'separator')
        )
      })

    if (visibleItems.length === 0) {
      return
    }

    Menu.buildFromTemplate(visibleItems).popup({ window: ownerWindow })
  })
}

function createWindow(): void {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize

  // Create the browser window.
  const mainWindow = new BrowserWindow({
    title: 'Synora',
    width: Math.floor(width * 0.9),
    height: Math.floor(height * 0.9),
    show: false,
    autoHideMenuBar: true,
    ...(process.platform === 'linux' ? { icon } : {}),
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      webviewTag: true,
    },
  })
  setMainWindow(mainWindow)

  mainWindow.once('ready-to-show', () => {
    mainWindow.show()
  })

  // Fallback: If ready-to-show is delayed or doesn't fire under software rendering / virtual display,
  // ensure the window is shown so the UI is visible.
  setTimeout(() => {
    if (!mainWindow.isDestroyed() && !mainWindow.isVisible()) {
      mainWindow.show()
    }
  }, 1000)

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  // HMR for renderer base on electron-vite cli.
  // Load the remote URL for development or the local html file for production.
  if (is.dev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }

  if (is.dev) {
    mainWindow.webContents.openDevTools()
  }

  mainWindow.webContents.on('will-attach-webview', (_, webPreferences) => {
    webPreferences.sandbox = false
    webPreferences.additionalArguments = [...(webPreferences.additionalArguments || []), '--nora-tab-guest']
    webPreferences.preload = join(__dirname, '../preload/index.js')
    // Load the preload in iframes too, so the YouTube ad guard reaches embedded
    // players (a YouTube video on Reddit is an iframe on youtube.com, and it
    // fetches its own player response). The preload keeps the renderer bridge
    // main-frame only, and context isolation still applies per frame.
    webPreferences.nodeIntegrationInSubFrames = true
  })

  attachDownloadHandler(mainWindow.webContents.session)
  attachContextMenu(mainWindow.webContents, mainWindow)

  mainWindow.webContents.session.webRequest.onHeadersReceived((details, cb) => {
    if (details.resourceType === 'image' && details.responseHeaders) {
      for (const k of Object.keys(details.responseHeaders)) {
        if (k.toLowerCase() === 'cross-origin-resource-policy') {
          delete details.responseHeaders[k]
        }
      }
    }
    cb({ responseHeaders: details.responseHeaders })
  })
  mainWindow.webContents.on('did-attach-webview', (e, wc) => {
    // Electron's webContents.executeJavaScript queues work behind once('did-stop-loading')
    // until the page can run JS. We fire several executeJavaScript calls per page (content
    // script, settings, user styles, user scripts) while a tab is still loading, so the
    // transient once-listeners can exceed Node's default cap of 10 and emit a spurious
    // MaxListenersExceededWarning. Raise the cap so the warning doesn't fire (the listeners
    // clear themselves once the page stops loading).
    wc.setMaxListeners(50)
    attachGuestShortcuts(wc, (input) => uiClient.handleGuestShortcut(input, wc.id))
    attachGuestNotifications(wc, mainWindow, (id) => uiClient.activateNotificationTab(id))
    attachWebRtcProtection(wc)
    attachDownloadHandler(wc.session)
    // clipboard-sanitized-write backs navigator.clipboard.writeText(), used by
    // in-page "Copy" buttons. Clipboard reads stay denied.
    const allowedPermissions = new Set(['notifications', 'clipboard-sanitized-write'])
    wc.session.setPermissionRequestHandler((_wc, permission, callback) => {
      callback(allowedPermissions.has(permission))
    })
    // Keep the synchronous check path in sync with the request handler above,
    // so a site querying navigator.permissions doesn't see a permission it
    // would then be denied.
    wc.session.setPermissionCheckHandler((_wc, permission) => allowedPermissions.has(permission))
    attachContextMenu(wc, mainWindow)
    setupGoogleAuthSession(wc.session)
    wc.on('did-create-window', (childWindow) => {
      setupGoogleAuthSession(childWindow.webContents.session)
      childWindow.webContents.on('will-navigate', (_event, targetUrl) => {
        if (isGoogleAuthUrl(targetUrl)) {
          childWindow.webContents.setUserAgent(FIREFOX_UA)
        }
        if (targetUrl.startsWith('nora:')) {
          childWindow.close()
          uiClient.handleDeeplink(targetUrl)
        }
      })
      childWindow.webContents.on('will-redirect', (_event, targetUrl) => {
        if (isGoogleAuthUrl(targetUrl)) {
          childWindow.webContents.setUserAgent(FIREFOX_UA)
        }
        if (targetUrl.startsWith('nora:')) {
          childWindow.close()
          uiClient.handleDeeplink(targetUrl)
        }
      })
    })

    wc.setWindowOpenHandler((details) => {
      if (isWatchPage(wc.id)) return { action: 'deny' }
      const url = normalizeExternalTargetUrl(details.url)

      // Google OAuth and social sign-in popups (LinkedIn, X/Twitter, etc.):
      // Open as a child popup BrowserWindow with window.opener preserved so the
      // OAuth flow can communicate with the opening page and close when complete.
      if (isOAuthPopupUrl(url, details.referrer.url || wc.getURL())) {
        return {
          action: 'allow',
          overrideBrowserWindowOptions: {
            width: 520,
            height: 680,
            autoHideMenuBar: true,
            webPreferences: {
              sandbox: false,
              contextIsolation: true,
            },
          },
        }
      }

      if (shouldOpenInSystemBrowser(url, details.referrer.url || wc.getURL())) {
        shell.openExternal(url)
      } else if (isHttpUrl(url)) {
        uiClient.openTab(url, wc.id)
      }
      return { action: 'deny' }
    })
    wc.on('will-navigate', (event, rawUrl) => {
      // The hidden page reading a watched profile stays on the web, out of sight.
      if (isWatchPage(wc.id)) {
        if (!isHttpUrl(rawUrl)) event.preventDefault()
        return
      }
      const url = normalizeExternalTargetUrl(rawUrl)
      if (isGoogleAuthUrl(url)) {
        wc.setUserAgent(FIREFOX_UA)
        return
      }
      if (!shouldOpenInSystemBrowser(url, wc.getURL())) {
        return
      }
      event.preventDefault()
      shell.openExternal(url)
    })
  })
}

// The feed's kept photos and videos are served under a scheme of their own, which has to be
// declared before the app is ready.
registerWatchMediaScheme()

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.whenReady().then(() => {
  // Set app user model id for windows. It has to match the appId in
  // electron-builder.yml, which is the AUMID electron-builder stamps on the
  // installed shortcut, otherwise Windows drops our toast notifications.
  electronApp.setAppUserModelId('jp.nonbili.nora')

  initMainChannel()
  setupWatch()

  attachDownloadHandler(session.defaultSession)
  setupGoogleAuthSession(session.defaultSession)

  // Default open or close DevTools by F12 in development
  // and ignore CommandOrControl + R in production.
  // see https://github.com/alex8088/electron-toolkit/tree/master/packages/utils
  app.on('browser-window-created', (_, window) => {
    optimizer.watchWindowShortcuts(window)
  })

  createWindow()

  if (app.hasSingleInstanceLock()) {
    exportApplication()
  }

  app.on('activate', function () {
    // On macOS it's common to re-create a window in the app when the
    // dock icon is clicked and there are no other windows open.
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })

  if (import.meta.env.VITE_BUILD_TARGET != 'portable') {
    genDesktopFile()
  }
})

// Quit when all windows are closed, except on macOS. There, it's common
// for applications and their menu bar to stay active until the user quits
// explicitly with Cmd + Q.
app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

bindDeeplink()

if (import.meta.env.VITE_BUILD_TARGET != 'portable') {
  checkForUpdate()
}
